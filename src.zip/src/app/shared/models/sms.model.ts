export interface SMSModel {
    id: Number;
    city: String;
    start_date: String;
    end_date: String;
    price: String;
    status: String;
    color: String;
}
