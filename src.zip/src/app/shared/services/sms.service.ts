import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SMSModel } from '../models/sms.model';

@Injectable({
  providedIn: 'root'
})
export class SMSService {

  uri = 'http://localhost:5000/api';

  constructor(private http: HttpClient) { }

  getSMSGroupList(): Observable<SMSModel[]> {
    return this.http.get<SMSModel[]>(`${this.uri}/smslists`);
  }

  filteredSMSListByDates(payload) {
    return this.http.post(`${this.uri}/smslists/filterByDate`, payload);
  }

  saveSMSGroupItem(payload) {
    return this.http.post(`${this.uri}/smslists/save`, payload);
  }

  updateSmsUpdate(smsUpdateBody) {
    return this.http.post(`${this.uri}/smslists/update`, smsUpdateBody);
  }

  deleteSMSGroupItem(id) {
    return this.http.delete(`${this.uri}/smslists/delete/${id}`);
  }


  getGsectionById(id): Observable<SMSModel> {
    return this.http.get<SMSModel>(`${this.uri}/gsections/${id}`);
  }

  getGsectionsByCategory(category): Observable<SMSModel[]> {
    return this.http.get<SMSModel[]>(`${this.uri}/gsections/category/${category}`);
  }

  getGsectionsByContent(content): Observable<SMSModel[]> {
    return this.http.get<SMSModel[]>(`${this.uri}/gsections/content/${content}`);
  }

}
