import { Component, OnInit, Input, OnDestroy, Output, EventEmitter } from '@angular/core';
import { SMSService } from '../shared/services/sms.service';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import * as moment from 'moment/moment';

@Component({
  selector: 'app-sms-edit-list',
  templateUrl: './sms-edit-list.component.html',
  styleUrls: ['./sms-edit-list.component.css']
})
export class SmsviewEditComponent implements OnInit {
  @Input() getDataFromSMSViewList: any;
  @Input() getIntimatationButtonIsClicked: boolean;
  @Output() sendDataFromSMSEditList = new EventEmitter<any>();;

  public smsUserEditForm: FormGroup;

  // dateFormat = 'dd/MM/yyyy';
  dateFormat = 'MM/dd/yyyy';

  constructor(public smsService: SMSService, private formBuilder: FormBuilder) { }

  setDataFromSMSViewList = [];
  ngOnInit() {
    this.setDataFromSMSViewList = [this.getDataFromSMSViewList];
    if (this.getDataFromSMSViewList && Object.keys(this.getDataFromSMSViewList).length) {
      this.smsUserEditForm = this.formBuilder.group({
        id: this.getDataFromSMSViewList['id'],
        city: this.getDataFromSMSViewList['city'],
        startDate: this.getDataFromSMSViewList['start_date'],
        endDate: this.getDataFromSMSViewList['end_date'],
        price: this.getDataFromSMSViewList['price'],
        status: this.getDataFromSMSViewList['status'],
        color: this.getDataFromSMSViewList['color'],
      });
    }
    if (this.getIntimatationButtonIsClicked) {
      this.needToUpdateDocument();
    }
  }

  startDate: any;
  endDate: any;
  get smsUserEditFormFormControls() { return this.smsUserEditForm.controls; }

  onChange(event, value) {
    this.startDate = this.smsUserEditFormFormControls.startDate ? this.smsUserEditFormFormControls.startDate.value : '';
    this.endDate = this.smsUserEditFormFormControls.endDate ? this.smsUserEditFormFormControls.endDate.value : '';
  }
  needToUpdateDocument() {
    this.smsUserEditForm.patchValue({
      startDate: moment(this.startDate).format('MM/DD/YYYY'),
      endDate: moment(this.endDate).format('MM/DD/YYYY')
    })

    this.smsService.updateSmsUpdate(this.smsUserEditForm.value)
      .subscribe(data => {
        console.log(data)
      })
    this.sendDataFromSMSEditList.emit({ value: this.smsUserEditForm.value, stopLoader: false });
  }
}
