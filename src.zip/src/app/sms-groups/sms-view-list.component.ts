import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { SMSService } from '../shared/services/sms.service';
import { NzMessageService } from 'ng-zorro-antd/message';
import { NzNotificationService } from 'ng-zorro-antd/notification';
import { NzModalService } from 'ng-zorro-antd/modal';

@Component({
  selector: 'app-sms-view-list',
  templateUrl: './sms-view-list.component.html',
  styleUrls: ['./sms-view-list.component.css']
})
export class SmsviewListComponent implements OnInit {
  listOfSMSData: any
  // dateFormat = 'dd/MM/yyyy';
  dateFormat = 'MM/dd/yyyy';

  constructor(
    public smsService: SMSService,
    private message: NzMessageService,
    private notification: NzNotificationService,
    private modal: NzModalService
  ) { }

  ngOnInit(): void {
    this.initalServiceLoad();
  }

  initalServiceLoad() {
    const id = this.message.loading('Fetching Records..', { nzDuration: 0 }).messageId;
    this.smsService.getSMSGroupList()
      .subscribe(data => {
        if (data && Object.keys(data).length) {
          this.listOfSMSData = data['results'];
          this.message.remove(id);
        }
      })
  }

  startDate: any;
  endDate: any
  searchDataByDates() {
    const id = this.message.loading('Fetching Records..', { nzDuration: 0 }).messageId;
    if (this.startDate && this.endDate) {
      let payload = { start: this.startDate, end: this.endDate };
      this.smsService.filteredSMSListByDates(payload)
        .subscribe(data => {
          if (data && Object.keys(data).length) {
            this.listOfSMSData = data['results'];
            this.message.remove(id);
          }
        })
    }
  }

  openSMSModalFl = false;
  isVisible = false;
  sendDataToSMSEditList = [];
  openSMSModal(data) {
    this.isVisible = true;
    this.openSMSModalFl = true;
    this.sendDataToSMSEditList = data;
  }

  deleteSMSModal(data) {
    const id = this.message.loading('Record Deleting..', { nzDuration: 300 }).messageId;
    let item = data.id;
    this.smsService.deleteSMSGroupItem(data.id)
      .subscribe(data => {
        console.log(data)
        this.notification.success(`${item}`, 'Record Deleted')
        this.initalServiceLoad();
        this.message.remove(id);
      })
  }

  viewEditSMSListCancel() {
    this.isVisible = false;
    this.openSMSModalFl = false;
  }

  isConfirmLoading = false;
  sendIntimatationButtonIsClicked = false;
  viewEditSMSListOK() {
    this.isConfirmLoading = true;
    this.sendIntimatationButtonIsClicked = true;
  }

  getDataFromSMSEditList(data) {
    this.isVisible = false;
    this.openSMSModalFl = false;
    this.isConfirmLoading = false;
    this.initalServiceLoad();
  }
}
